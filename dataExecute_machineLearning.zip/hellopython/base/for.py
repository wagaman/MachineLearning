__author__ = 'Administrator'


A = 2
for player in range(A):
    print(player)