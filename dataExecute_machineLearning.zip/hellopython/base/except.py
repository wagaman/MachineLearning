__author__ = 'Administrator'


try:
    print(1)
except Exception as e:
    # 如果发生错误则回滚
    print(e)
