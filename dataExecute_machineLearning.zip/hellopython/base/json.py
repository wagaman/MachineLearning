__author__ = 'Administrator'
import json

json_str = '{"max":10,"numRaters":79,"average":"9.1","min":0}'

json_data = json.loads(json_str)