__author__ = 'sss'

numbers = [1, 2, 3, 4, 5]
doubled_odds = [n * 2 for n in numbers if n % 2 == 1]
print(doubled_odds)


