__author__ = 'Administrator'


print( int(34.7) )


print( float(34) )


print( str(34) )