__author__ = 'Administrator'
print(int(56 / 10))
print(56 / 10 + 1)