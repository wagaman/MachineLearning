__author__ = 'sss'

'''

http://wenshu.court.gov.cn/ValiCode/CreateCode/?guid=c1dfcef5-0f21-a1cbdd3d-cfce0f43422e

http://wenshu.court.gov.cn/List/ValiYzm


number:nezq
valiGuid:c1dfcef5-0f21-a1cbdd3d-cfce0f43422e

'''

if __name__ == '__main__':
    print(1)