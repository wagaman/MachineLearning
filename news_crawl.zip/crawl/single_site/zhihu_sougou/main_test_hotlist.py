__author__ = 'Administrator'

from single_site.zhihu_sougou import zhihu_crawler


hotword = zhihu_crawler.get_hotlist()
print(hotword)




