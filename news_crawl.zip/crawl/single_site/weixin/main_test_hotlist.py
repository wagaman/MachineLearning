__author__ = 'Administrator'

from single_site.weixin import wx_crawler


hotword = wx_crawler.get_hotlist()
print(hotword)




